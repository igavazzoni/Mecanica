/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.exemplobigdecimal;

import java.math.BigDecimal;

/**
 *
 * @author aluno
 */
public class ExemploBigDecimal {

    public static void main(String[] args) {
        
      new FrameCadastro().setVisible(true);
        
        
        
    }
}
